'use client'
import { createBrowserClient } from '@supabase/ssr'

function getUrl()  { return process.env.NEXT_PUBLIC_SUPABASE_URL! }
function getAnon() { return process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY! }

export function createClient() {
  return createBrowserClient(getUrl(), getAnon())
}
