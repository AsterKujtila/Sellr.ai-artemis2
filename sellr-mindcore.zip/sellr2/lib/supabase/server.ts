import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

function getUrl()  { return process.env.NEXT_PUBLIC_SUPABASE_URL! }
function getAnon() { return process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY! }

export async function createClient() {
  const cookieStore = await cookies()
  return createServerClient(getUrl(), getAnon(), {
    cookies: {
      getAll()            { return cookieStore.getAll() },
      setAll(toSet) {
        try { toSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options)) }
        catch {}
      },
    },
  })
}
