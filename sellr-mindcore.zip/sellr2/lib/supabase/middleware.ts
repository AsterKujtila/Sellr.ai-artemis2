import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

function getUrl()  { return process.env.NEXT_PUBLIC_SUPABASE_URL! }
function getAnon() { return process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY! }

export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({ request: { headers: request.headers } })

  const supabase = createServerClient(getUrl(), getAnon(), {
    cookies: {
      getAll()      { return request.cookies.getAll() },
      setAll(toSet) {
        toSet.forEach(({ name, value, options }) => {
          request.cookies.set(name, value)
          response.cookies.set(name, value, options)
        })
      },
    },
  })

  const { data: { user } } = await supabase.auth.getUser()

  const path = request.nextUrl.pathname
  const isPublic = path === '/login' || path.startsWith('/auth/') || path === '/api/auth/google'

  if (isPublic) return response

  if (!user) {
    const url = request.nextUrl.clone()
    url.pathname = '/login'
    return NextResponse.redirect(url)
  }

  return response
}
