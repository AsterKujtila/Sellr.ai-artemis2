'use client'
import { useState } from 'react'
import { ArrowUp, Copy, Check } from 'lucide-react'
import { cn } from '@/lib/utils'

function Thinking() {
  return (
    <div className="flex flex-col items-center gap-3 py-12">
      <div className="flex gap-1.5">
        {[0,1,2].map(i=><div key={i} className="w-1.5 h-1.5 rounded-full bg-primary" style={{animation:`dotb .72s ease-in-out ${i*.15}s infinite`}}/>)}
      </div>
      <p className="text-xs text-foreground/40 font-sans italic">Analyzing your store...</p>
    </div>
  )
}

export default function StoreView() {
  const [url, setUrl]   = useState('')
  const [desc, setDesc] = useState('')
  const [result, setResult] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [ran, setRan] = useState(false)

  const run = async () => {
    if (!desc.trim()) { setErr('Please describe your store.'); return }
    setErr(null); setLoading(true); setResult(null); setRan(true)
    try {
      const prompt = `Analyze this Whop store:\n\nURL: ${url||'not provided'}\nDescription: ${desc}\n\n**OVERALL SCORE: X/100**\nOne-line verdict.\n\n**TOP 3 REVENUE LEAKS**\nFor each: Problem → Impact → Exact Fix → Est. Recovery\n\n**QUICK WINS (this week)**\n3 things doable in under 2 hours.\n\n**OFFER REVIEW**\nPositioning, price, what's missing.\n\n→ Next step: The single most important thing to do today.`
      const r = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: prompt }] }) })
      const d = await r.json()
      if (!r.ok || d.error) throw new Error(d.error || 'Error')
      setResult(d.text)
    } catch (e: any) { setErr(e.message); setRan(false) }
    setLoading(false)
  }

  const inp = 'w-full bg-transparent text-sm font-sans text-foreground placeholder:text-foreground/25 outline-none'

  return (
    <div className="flex flex-col h-full">
      <div className="px-5 pt-14 pb-4 shrink-0">
        <h1 className="text-2xl font-serif" style={{ fontWeight: 300, letterSpacing: '-.02em' }}>Store Analyzer</h1>
        <p className="text-xs text-foreground/40 mt-0.5">Get an instant AI revenue diagnosis.</p>
      </div>

      <div className="flex-1 overflow-y-auto touch-scroll no-scrollbar px-4 pb-28 flex flex-col gap-4">

        {!ran ? (
          <>
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-sans font-bold text-foreground/50 uppercase tracking-widest">Whop Store URL</label>
              <div className="glass rounded-xl px-3 py-2.5">
                <input value={url} onChange={e=>setUrl(e.target.value)} type="text" placeholder="whop.com/your-store" className={inp} />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-sans font-bold text-foreground/50 uppercase tracking-widest">Describe Your Store</label>
              <div className="glass rounded-xl px-3 py-2.5">
                <textarea value={desc} onChange={e=>setDesc(e.target.value)} rows={6} placeholder="What do you sell? Audience? Price? Conversion rate? Current problems?" className={cn(inp, 'resize-none leading-relaxed')} style={{ minHeight: 120 }} />
              </div>
            </div>
            {err && <button onClick={()=>setErr(null)} className="text-xs text-destructive/80 px-3 py-2 rounded-xl border border-destructive/20 bg-destructive/5 text-left">⚠️ {err}</button>}
            <button onClick={run} className="w-full py-3.5 rounded-full font-sans font-semibold text-sm flex items-center justify-center gap-2 bg-primary text-white hover:bg-primary/90 transition-all">
              <ArrowUp size={15} /> Analyze My Store
            </button>
          </>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <button onClick={() => { setRan(false); setResult(null) }} className="text-xs text-foreground/50 hover:text-foreground transition-colors">← New analysis</button>
              {result && (
                <button onClick={() => { navigator.clipboard?.writeText(result).catch(()=>{}); setCopied(true); setTimeout(()=>setCopied(false),2000) }}
                  className={cn('flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full glass transition-colors', copied?'text-green-400':'text-foreground/50')}>
                  {copied ? <Check size={11}/> : <Copy size={11}/>}
                  {copied ? 'Copied' : 'Copy'}
                </button>
              )}
            </div>
            {loading && <Thinking />}
            {result && !loading && (
              <div className="glass rounded-2xl p-4 text-sm font-sans font-light text-foreground leading-relaxed whitespace-pre-wrap">
                {result}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
