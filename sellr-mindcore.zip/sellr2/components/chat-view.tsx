'use client'
import { useState, useRef, useEffect, useCallback } from 'react'
import { ArrowUp, Mic, MicOff, Copy, Volume2, RotateCcw } from 'lucide-react'
import { cn } from '@/lib/utils'

type Msg = { id: string; role: 'user' | 'assistant'; text: string }

const CHIPS = [
  "Why isn't my store converting?",
  "Write my offer headline",
  "How to price my community?",
  "Roast my sales page",
  "Create a 7-day launch plan",
  "What upsells should I add?",
  "How to grow on Whop?",
  "Analyze my checkout funnel",
]

const PLACEHOLDERS = [
  'You can start mid-sentence.',
  'Messy thoughts are welcome.',
  'Ask me anything about Whop.',
  'What\'s blocking your revenue?',
]

function id() { return Math.random().toString(36).slice(2) }

function ThinkingDots() {
  return (
    <div className="flex items-center gap-1.5 px-4 py-3 rounded-2xl glass max-w-[80px]">
      {[0, 1, 2].map(i => (
        <div
          key={i}
          className="w-1.5 h-1.5 rounded-full bg-primary"
          style={{ animation: `dotb .72s ease-in-out ${i * .15}s infinite` }}
        />
      ))}
    </div>
  )
}

export default function ChatView({ name }: { name: string }) {
  const firstName = (name || 'there').split(' ')[0]
  const [msgs, setMsgs] = useState<Msg[]>([{
    id: id(),
    role: 'assistant',
    text: `Hey ${firstName} 👋 I'm SELLR — your AI sales coach built for Whop.\n\nAsk me anything about your store, pricing, offers, or copy. Specific, real advice — no fluff.\n\nWhat's the biggest problem with your Whop store right now?`,
  }])
  const [input, setInput]     = useState('')
  const [loading, setLoading] = useState(false)
  const [err, setErr]         = useState<string | null>(null)
  const [chips, setChips]     = useState(true)
  const [micOn, setMicOn]     = useState(false)
  const [hasMic, setHasMic]   = useState(false)
  const [phIdx, setPhIdx]     = useState(0)
  const bottomRef = useRef<HTMLDivElement>(null)
  const taRef     = useRef<HTMLTextAreaElement>(null)
  const recRef    = useRef<any>(null)
  const ttsRef    = useRef<SpeechSynthesisUtterance | null>(null)

  // Rotate placeholders
  useEffect(() => {
    const t = setInterval(() => setPhIdx(p => (p + 1) % PLACEHOLDERS.length), 4500)
    return () => clearInterval(t)
  }, [])

  // Voice setup
  useEffect(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (!SR) return
    setHasMic(true)
    const r = new SR(); r.continuous = false; r.lang = 'en-US'
    r.onresult = (e: any) => { const t = e.results[0]?.[0]?.transcript || ''; if (t) send(t) }
    r.onend = () => setMicOn(false)
    r.onerror = () => setMicOn(false)
    recRef.current = r
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [msgs, loading])

  const send = useCallback(async (override?: string) => {
    const text = (override ?? input).trim()
    if (!text || loading) return
    setInput(''); setErr(null); setChips(false)
    if (taRef.current) taRef.current.style.height = 'auto'

    const userMsg: Msg = { id: id(), role: 'user', text }
    const next = [...msgs, userMsg]
    setMsgs(next); setLoading(true)

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next.map(m => ({ role: m.role, content: m.text })) }),
      })
      const data = await res.json()
      if (!res.ok || data.error) throw new Error(data.error || `Error ${res.status}`)
      setMsgs(p => [...p, { id: id(), role: 'assistant', text: data.text }])
    } catch (e: any) {
      setErr(e.message || 'Something went wrong. Try again.')
    } finally {
      setLoading(false)
    }
  }, [input, msgs, loading])

  const toggleMic = () => {
    if (!recRef.current) return
    if (micOn) { recRef.current.stop(); setMicOn(false) }
    else { try { recRef.current.start(); setMicOn(true) } catch { setMicOn(false) } }
  }

  const speak = (text: string, btn: HTMLButtonElement) => {
    if (!window.speechSynthesis) return
    if (ttsRef.current) { window.speechSynthesis.cancel(); ttsRef.current = null; btn.setAttribute('data-tts', ''); return }
    const u = new SpeechSynthesisUtterance(text.slice(0, 600))
    u.rate = 1.05
    const v = window.speechSynthesis.getVoices().find(v => v.lang === 'en-US')
    if (v) u.voice = v
    u.onend = u.onerror = () => { ttsRef.current = null; btn.removeAttribute('data-tts') }
    ttsRef.current = u; btn.setAttribute('data-tts', '1')
    window.speechSynthesis.speak(u)
  }

  const copyText = (text: string, btn: HTMLButtonElement) => {
    navigator.clipboard?.writeText(text).catch(() => {})
    const orig = btn.innerHTML
    btn.innerHTML = '✓'
    setTimeout(() => { btn.innerHTML = orig }, 2000)
  }

  const date = new Date()
  const days = ['SUNDAY','MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY']
  const months = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']
  const dateStr = `${days[date.getDay()]} ${date.getDate()} ${months[date.getMonth()]}`

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-5 pt-14 pb-3 shrink-0">
        <div>
          <p className="text-xs font-mono text-foreground/40 tracking-widest">{dateStr}</p>
          <h1 className="text-2xl font-serif mt-0.5" style={{ fontWeight: 300, letterSpacing: '-.02em' }}>
            Hey {firstName}
          </h1>
        </div>
        <button
          onClick={() => { setMsgs([{ id: id(), role: 'assistant', text: 'Fresh start 🔥 What do you want to work on?' }]); setChips(true); setErr(null) }}
          className="p-2 rounded-full glass text-foreground/60 hover:text-foreground transition-colors"
        >
          <RotateCcw size={16} />
        </button>
      </div>

      {/* Quick chips */}
      {chips && (
        <div className="flex gap-2 overflow-x-auto no-scrollbar px-5 pb-3 shrink-0">
          {CHIPS.map((c, i) => (
            <button
              key={i}
              onClick={() => { setChips(false); send(c) }}
              className="shrink-0 glass rounded-full px-3 py-1.5 text-xs font-sans text-foreground/70 hover:text-foreground hover:border-primary/50 transition-all whitespace-nowrap"
            >
              {c}
            </button>
          ))}
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto touch-scroll no-scrollbar px-4 py-2 flex flex-col gap-3">
        {msgs.map((m, i) => (
          <div
            key={m.id}
            className={cn('flex flex-col gap-1.5', m.role === 'user' ? 'items-end' : 'items-start')}
            style={{ animation: 'msgIn .3s ease' }}
          >
            <div className={cn(
              'max-w-[88%] px-4 py-3 rounded-2xl text-sm font-sans font-light leading-relaxed whitespace-pre-wrap break-words',
              m.role === 'user'
                ? 'rounded-br-sm text-white'
                : 'glass rounded-bl-sm text-foreground',
            )}
            style={m.role === 'user' ? { background: 'rgba(196,114,74,.85)' } : {}}>
              {m.text}
            </div>
            {m.role === 'assistant' && i > 0 && (
              <div className="flex gap-1.5 ml-1">
                <button
                  onClick={e => copyText(m.text, e.currentTarget as HTMLButtonElement)}
                  className="w-7 h-7 rounded-full glass flex items-center justify-center text-foreground/50 hover:text-foreground transition-colors text-xs"
                >
                  <Copy size={11} />
                </button>
                <button
                  onClick={e => speak(m.text, e.currentTarget as HTMLButtonElement)}
                  className="w-7 h-7 rounded-full glass flex items-center justify-center text-foreground/50 hover:text-foreground transition-colors"
                >
                  <Volume2 size={11} />
                </button>
              </div>
            )}
          </div>
        ))}

        {loading && <ThinkingDots />}

        {err && (
          <button
            onClick={() => setErr(null)}
            className="self-center text-xs text-destructive/80 px-4 py-2 rounded-xl border border-destructive/20 bg-destructive/5 hover:bg-destructive/10 transition-colors"
            style={{ animation: 'msgIn .3s ease' }}
          >
            ⚠️ {err} · tap to dismiss
          </button>
        )}

        <div ref={bottomRef} className="h-1" />
      </div>

      {/* Input area */}
      <div className="shrink-0 px-4 pb-28 pt-2">
        {micOn && (
          <p className="text-center text-xs text-primary font-medium mb-2" style={{ animation: 'fade .3s ease' }}>
            🎤 Listening...
          </p>
        )}
        <div className="glass-strong rounded-2xl px-3 py-2 flex items-end gap-2">
          <textarea
            ref={taRef}
            value={input}
            onChange={e => {
              setInput(e.target.value)
              e.target.style.height = 'auto'
              e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px'
            }}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
            placeholder={PLACEHOLDERS[phIdx]}
            disabled={loading}
            maxLength={800}
            rows={1}
            className="flex-1 bg-transparent text-sm font-sans text-foreground placeholder:text-foreground/30 resize-none outline-none leading-relaxed min-h-[36px] max-h-[120px] py-1.5"
          />
          {hasMic && (
            <button
              onClick={toggleMic}
              className={cn(
                'w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all',
                micOn ? 'bg-primary/20 text-primary' : 'text-foreground/40 hover:text-foreground'
              )}
            >
              {micOn ? <MicOff size={15} /> : <Mic size={15} />}
            </button>
          )}
          <button
            onClick={() => send()}
            disabled={loading || !input.trim()}
            className={cn(
              'w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all',
              loading || !input.trim()
                ? 'bg-foreground/10 text-foreground/30 cursor-not-allowed'
                : 'bg-primary text-white hover:bg-primary/90'
            )}
          >
            <ArrowUp size={15} />
          </button>
        </div>
        <p className="text-[10px] text-foreground/25 text-right mt-1.5 font-mono">
          {input.length}/800
        </p>
      </div>
    </div>
  )
}
