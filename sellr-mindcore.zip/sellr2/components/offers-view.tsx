'use client'
import { useState } from 'react'
import { ArrowUp, Copy, Check } from 'lucide-react'
import { cn } from '@/lib/utils'

const STYLES = ['bold', 'soft', 'urgency', 'story']

function Thinking() {
  return (
    <div className="flex flex-col items-center gap-3 py-12">
      <div className="flex gap-1.5">
        {[0,1,2].map(i=><div key={i} className="w-1.5 h-1.5 rounded-full bg-primary" style={{animation:`dotb .72s ease-in-out ${i*.15}s infinite`}}/>)}
      </div>
      <p className="text-xs text-foreground/40 font-sans italic">Writing your offer...</p>
    </div>
  )
}

export default function OffersView() {
  const [style, setStyle] = useState('bold')
  const [result, setResult] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [view, setView] = useState<'form' | 'result'>('form')

  const run = async () => {
    const prod  = (document.getElementById('op')  as HTMLInputElement)?.value.trim()
    const aud   = (document.getElementById('oa')  as HTMLTextAreaElement)?.value.trim()
    const out   = (document.getElementById('oo')  as HTMLInputElement)?.value.trim()
    const price = (document.getElementById('opr') as HTMLInputElement)?.value.trim()
    if (!prod) { setErr('Product name is required.'); return }
    setErr(null); setLoading(true); setResult(null); setView('result')

    try {
      const prompt = `Write a complete high-converting Whop offer page:\n\nProduct: ${prod}\nAudience: ${aud||'not specified'}\nOutcome: ${out||'not specified'}\nPrice: ${price||'not specified'}\nStyle: ${style}\n\nProvide:\n\n**HEADLINE** (under 10 words)\n\n**SUBHEADLINE** (1 sentence)\n\n**BULLET POINTS** (5x starting with ✓)\n\n**CTA BUTTON** (under 6 words)\n\n**TRUST LINE** (guarantee or social proof)\n\n---\n**CRITIQUE:** Strongest element + best A/B test to run first.`
      const r = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [{ role: 'user', content: prompt }] }),
      })
      const d = await r.json()
      if (!r.ok || d.error) throw new Error(d.error || 'Error')
      setResult(d.text)
    } catch (e: any) {
      setErr(e.message); setView('form')
    }
    setLoading(false)
  }

  const inp = 'w-full bg-transparent text-sm font-sans text-foreground placeholder:text-foreground/25 outline-none'
  const field = (label: string, id: string, ph: string, multi = false) => (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-[10px] font-sans font-bold text-foreground/50 uppercase tracking-widest">{label}</label>
      <div className="glass rounded-xl px-3 py-2.5">
        {multi
          ? <textarea id={id} rows={2} placeholder={ph} className={cn(inp, 'resize-none leading-relaxed')} />
          : <input id={id} type="text" placeholder={ph} className={inp} />}
      </div>
    </div>
  )

  return (
    <div className="flex flex-col h-full">
      <div className="px-5 pt-14 pb-4 shrink-0">
        <h1 className="text-2xl font-serif" style={{ fontWeight: 300, letterSpacing: '-.02em' }}>Offer Builder</h1>
        <p className="text-xs text-foreground/40 mt-0.5">SELLR writes your complete copy.</p>
      </div>

      {view === 'form' ? (
        <div className="flex-1 overflow-y-auto touch-scroll no-scrollbar px-4 pb-28 flex flex-col gap-4">
          {field('Product / Service', 'op', 'e.g. Fitness coaching community')}
          {field('Target Audience', 'oa', 'e.g. Online coaches under $5k/mo', true)}
          {field('Main Outcome', 'oo', 'e.g. Double revenue in 60 days')}
          {field('Price Point', 'opr', 'e.g. $47/mo, $197 one-time')}

          <div className="flex flex-col gap-2">
            <label className="text-[10px] font-sans font-bold text-foreground/50 uppercase tracking-widest">Copy Style</label>
            <div className="grid grid-cols-4 gap-2">
              {STYLES.map(s => (
                <button key={s} onClick={() => setStyle(s)}
                  className={cn('py-2 rounded-xl text-xs font-sans font-medium capitalize transition-all border',
                    style === s ? 'bg-primary/15 border-primary/40 text-primary' : 'glass border-transparent text-foreground/50'
                  )}>
                  {s}
                </button>
              ))}
            </div>
          </div>

          {err && (
            <button onClick={() => setErr(null)} className="text-xs text-destructive/80 px-3 py-2 rounded-xl border border-destructive/20 bg-destructive/5 text-left">
              ⚠️ {err}
            </button>
          )}

          <button onClick={run}
            className="w-full py-3.5 rounded-full font-sans font-semibold text-sm flex items-center justify-center gap-2 transition-all bg-primary text-white hover:bg-primary/90">
            <ArrowUp size={15} /> Generate Offer Copy
          </button>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto touch-scroll no-scrollbar px-4 pb-28 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <button onClick={() => setView('form')} className="text-xs text-foreground/50 hover:text-foreground transition-colors">← Back</button>
            {result && (
              <button onClick={() => { navigator.clipboard?.writeText(result).catch(()=>{}); setCopied(true); setTimeout(()=>setCopied(false), 2000) }}
                className={cn('flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full glass transition-colors', copied ? 'text-green-400' : 'text-foreground/50')}>
                {copied ? <Check size={11} /> : <Copy size={11} />}
                {copied ? 'Copied' : 'Copy all'}
              </button>
            )}
          </div>
          {loading && <Thinking />}
          {result && !loading && (
            <div className="glass rounded-2xl p-4 text-sm font-sans font-light text-foreground leading-relaxed whitespace-pre-wrap">
              {result}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
