'use client'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import { cn } from '@/lib/utils'

const PLANS = [
  { n: 'Starter', p: 19,  cr: 200,  feats: ['Store Analyzer','Offer Builder','AI Chat','Never expires'], hot: false },
  { n: 'Pro',     p: 49,  cr: 600,  feats: ['Everything in Starter','Launch Builder','Unlimited history','Priority support'], hot: true  },
  { n: 'Scale',   p: 99,  cr: 1500, feats: ['Everything in Pro','Founder access','1:1 onboarding','Custom integrations'], hot: false },
]

export default function CreditsView({ name, avatar }: { name: string; avatar?: string | null }) {
  const router = useRouter()

  const logout = async () => {
    const sb = createClient()
    await sb.auth.signOut()
    router.replace('/login')
    router.refresh()
  }

  return (
    <div className="flex flex-col h-full">
      <div className="px-5 pt-14 pb-4 shrink-0">
        <h1 className="text-2xl font-serif" style={{ fontWeight: 300, letterSpacing: '-.02em' }}>Credits</h1>
        <p className="text-xs text-foreground/40 mt-0.5">Power your AI features.</p>
      </div>

      <div className="flex-1 overflow-y-auto touch-scroll no-scrollbar px-4 pb-28 flex flex-col gap-4">

        {/* Balance card */}
        <div className="glass rounded-2xl p-4">
          <p className="text-[10px] font-sans font-bold text-foreground/40 uppercase tracking-widest mb-2">Credits remaining</p>
          <div className="flex items-baseline gap-1.5">
            <span className="text-5xl font-serif font-black text-primary" style={{ letterSpacing: '-.03em' }}>18</span>
            <span className="text-base text-foreground/40">/ 20</span>
          </div>
          <div className="mt-3 h-1.5 rounded-full bg-white/10">
            <div className="h-full rounded-full bg-primary" style={{ width: '90%' }} />
          </div>
          <p className="text-[10px] text-foreground/30 mt-2 font-sans">Chat = 1 · Offers = 2 · Store = 3</p>
        </div>

        {/* Plans */}
        {PLANS.map(p => (
          <div key={p.n} className={cn('rounded-2xl p-4 relative', p.hot ? 'bg-primary/15 border border-primary/30' : 'glass')}>
            {p.hot && (
              <div className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-primary text-white text-[9px] font-bold px-3 py-0.5 rounded-full tracking-wider">
                BEST VALUE
              </div>
            )}
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className={cn('text-[10px] font-bold uppercase tracking-widest mb-1', p.hot ? 'text-primary/70' : 'text-foreground/40')}>{p.n}</p>
                <div className="flex items-baseline gap-1">
                  <span className={cn('text-3xl font-serif font-black', p.hot ? 'text-primary' : 'text-foreground')} style={{ letterSpacing: '-.03em' }}>${p.p}</span>
                  <span className="text-xs text-foreground/30">one-time</span>
                </div>
              </div>
              <div className={cn('px-3 py-1 rounded-full text-xs font-semibold', p.hot ? 'bg-primary/20 text-primary' : 'glass text-foreground/60')}>
                ⚡ {p.cr} credits
              </div>
            </div>
            <div className="flex flex-col gap-1.5 mb-3">
              {p.feats.map((f, i) => (
                <div key={i} className="flex items-center gap-2 text-xs text-foreground/60 font-sans">
                  <span className="text-primary">✓</span>{f}
                </div>
              ))}
            </div>
            <button className={cn('w-full py-2.5 rounded-full font-sans font-semibold text-sm transition-all', p.hot ? 'bg-primary text-white hover:bg-primary/90' : 'glass text-foreground hover:text-foreground/80')}>
              Get {p.n} →
            </button>
          </div>
        ))}

        {/* Profile / logout */}
        <div className="glass rounded-2xl p-4 flex items-center gap-3">
          {avatar
            ? <img src={avatar} alt="" width={40} height={40} className="rounded-full object-cover shrink-0" />
            : <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center shrink-0 text-sm font-bold text-primary">{(name||'?').slice(0,2).toUpperCase()}</div>
          }
          <div className="flex-1 min-w-0">
            <p className="text-sm font-sans font-medium text-foreground truncate">{name}</p>
            <p className="text-xs text-foreground/40">Whop seller</p>
          </div>
          <button onClick={logout} className="text-xs text-foreground/40 hover:text-foreground/80 transition-colors font-sans">
            Sign out
          </button>
        </div>
      </div>
    </div>
  )
}
