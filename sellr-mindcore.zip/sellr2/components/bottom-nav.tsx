'use client'
import { cn } from '@/lib/utils'
import { MessageCircle, PenLine, Search, Zap } from 'lucide-react'

export type Tab = 'chat' | 'offers' | 'history' | 'credits'

const TABS = [
  { id: 'chat'    as const, label: 'Chat',    Icon: MessageCircle },
  { id: 'offers'  as const, label: 'Offers',  Icon: PenLine       },
  { id: 'history' as const, label: 'History', Icon: Search        },
  { id: 'credits' as const, label: 'Credits', Icon: Zap           },
]

interface Props {
  active: Tab
  onChange: (t: Tab) => void
}

export function BottomNav({ active, onChange }: Props) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 pb-safe">
      <div
        className="glass-strong mx-4 mb-4 flex items-center justify-around rounded-full px-4 py-3 max-w-xs mx-auto"
        style={{ minHeight: 56 }}
      >
        {TABS.map(({ id, label, Icon }) => {
          const on = active === id
          return (
            <button
              key={id}
              type="button"
              onClick={() => onChange(id)}
              className={cn(
                'flex flex-1 flex-col items-center justify-center gap-1 py-1 rounded-xl transition-colors duration-200',
                on ? 'text-foreground' : 'text-foreground/45'
              )}
            >
              <Icon
                size={21}
                strokeWidth={on ? 2.25 : 1.75}
                className={cn('shrink-0', on && 'text-primary')}
              />
              <span className={cn(
                'text-[10px] font-sans leading-tight',
                on ? 'font-semibold text-primary' : 'font-medium text-foreground/45'
              )}>
                {label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
