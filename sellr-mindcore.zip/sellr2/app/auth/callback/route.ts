import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'

const SUPABASE_URL  = process.env.NEXT_PUBLIC_SUPABASE_URL!
const SUPABASE_ANON = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get('code')
  const cookieStore = await cookies()
  const verifier = cookieStore.get('sb-pkce-verifier')?.value

  if (!code || !verifier) {
    const msg = encodeURIComponent('Missing code or verifier. Try signing in again.')
    return NextResponse.redirect(`${origin}/login?error=auth&message=${msg}`)
  }

  const tokenRes = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=pkce`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      apikey: SUPABASE_ANON,
      Authorization: `Bearer ${SUPABASE_ANON}`,
    },
    body: JSON.stringify({ auth_code: code, code_verifier: verifier }),
  })

  const tokenData = await tokenRes.json()
  if (!tokenRes.ok || tokenData.error) {
    const msg = encodeURIComponent(tokenData?.error_description || 'Token exchange failed')
    return NextResponse.redirect(`${origin}/login?error=auth&message=${msg}`)
  }

  const { access_token, refresh_token } = tokenData
  if (!access_token || !refresh_token) {
    return NextResponse.redirect(`${origin}/login?error=auth&message=${encodeURIComponent('Invalid token response')}`)
  }

  const supabase = await createClient()
  const { error } = await supabase.auth.setSession({ access_token, refresh_token })
  if (error) {
    return NextResponse.redirect(`${origin}/login?error=auth&message=${encodeURIComponent(error.message)}`)
  }

  const response = NextResponse.redirect(`${origin}/chat`)
  response.cookies.set('sb-pkce-verifier', '', { path: '/', maxAge: 0, httpOnly: true, secure: true, sameSite: 'none' })
  return response
}
