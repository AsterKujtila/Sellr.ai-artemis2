'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { BottomNav, type Tab } from '@/components/bottom-nav'
import dynamic from 'next/dynamic'

const ChatView    = dynamic(() => import('@/components/chat-view'),    { ssr: false })
const OffersView  = dynamic(() => import('@/components/offers-view'),  { ssr: false })
const StoreView   = dynamic(() => import('@/components/history-view'), { ssr: false })
const CreditsView = dynamic(() => import('@/components/credits-view'), { ssr: false })

export default function Shell() {
  const router = useRouter()
  const [tab, setTab] = useState<Tab>('chat')
  const [user, setUser] = useState<{ name: string; avatar?: string | null } | null>(null)

  useEffect(() => {
    const sb = createClient()
    sb.auth.getUser().then(({ data: { user: u } }) => {
      if (!u) { router.replace('/login'); return }
      setUser({
        name: u.user_metadata?.full_name || u.user_metadata?.name || u.email?.split('@')[0] || 'Seller',
        avatar: u.user_metadata?.avatar_url || u.user_metadata?.picture || null,
      })
    })
  }, [router])

  if (!user) return (
    <div className="min-h-dvh flex items-center justify-center bg-background">
      <div style={{ width: 28, height: 28, border: '2.5px solid rgba(196,114,74,.3)', borderTopColor: '#c4724a', borderRadius: '50%', animation: 'spin .7s linear infinite' }} />
    </div>
  )

  return (
    <div className="min-h-dvh bg-background relative">
      {/* Subtle gradient background */}
      <div className="fixed inset-0 sellr-gradient opacity-100 pointer-events-none" />

      {/* Content */}
      <div className="relative z-10 h-dvh overflow-hidden">
        <div className="page-enter h-full">
          {tab === 'chat'    && <ChatView    name={user.name} />}
          {tab === 'offers'  && <OffersView />}
          {tab === 'history' && <StoreView />}
          {tab === 'credits' && <CreditsView name={user.name} avatar={user.avatar} />}
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNav active={tab} onChange={setTab} />

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes dotb { 0%,100%{transform:translateY(0) scale(1);opacity:.4} 50%{transform:translateY(-5px) scale(1.15);opacity:1} }
        @keyframes msgIn { from{opacity:0;transform:translateY(8px) scale(.97)} to{opacity:1;transform:none} }
        @keyframes fade { from{opacity:0} to{opacity:1} }
        .pb-safe { padding-bottom: env(safe-area-inset-bottom, 0); }
      `}</style>
    </div>
  )
}
