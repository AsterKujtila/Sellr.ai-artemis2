import Anthropic from '@anthropic-ai/sdk'
import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

const claude = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

const SYSTEM = `You are SELLR — an elite AI sales coach built exclusively for Whop sellers.

PERSONALITY: Direct, sharp, warm. Like a world-class sales consultant who genuinely cares. Roast bad ideas kindly, celebrate wins loudly, always give specific actionable fixes.

EXPERTISE: Whop platform, offer copywriting, conversion optimization, pricing strategy, launch planning, store analysis, A/B testing, community growth.

RULES:
1. Always be hyper-specific — never vague
2. Keep responses scannable with short paragraphs
3. If someone shares copy/offer, give direct honest critique with exact rewrites
4. End every response with "→ Next step:" + one clear action
5. Max 300 words unless explicitly asked for more
6. Use → for key points, 🔥 for wins, 💡 for insights — sparingly`

export async function POST(req: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  let messages: { role: 'user' | 'assistant'; content: string }[]
  try {
    const body = await req.json()
    messages = body.messages
    if (!Array.isArray(messages) || !messages.length) throw new Error()
  } catch {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 })
  }

  try {
    const res = await claude.messages.create({
      model: 'claude-opus-4-6',
      max_tokens: 1024,
      system: SYSTEM,
      messages: messages.map(m => ({ role: m.role, content: String(m.content).slice(0, 4000) })),
    })
    const text = res.content[0]?.type === 'text' ? res.content[0].text : ''
    return NextResponse.json({ text })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'API error' }, { status: 500 })
  }
}
