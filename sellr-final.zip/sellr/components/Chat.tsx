'use client'
import { useState, useRef, useEffect, useCallback } from 'react'

type Msg = { role: 'user' | 'assistant'; content: string }

const CHIPS = [
  "Why isn't my store converting?",
  "Write my offer headline",
  "How to price my community?",
  "Roast my sales page",
  "Create a 7-day launch plan",
  "What upsells should I add?",
  "Improve my product description",
  "How to grow on Whop?",
]

function Dots() {
  return (
    <div style={{ alignSelf: 'flex-start', padding: '10px 16px', background: '#2a1a14', borderRadius: 14, display: 'inline-flex', gap: 5, alignItems: 'center', animation: 'msgIn .3s ease' }}>
      {[0, 1, 2].map(i => (
        <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: '#c4724a', animation: `dot .72s ease-in-out ${i * .15}s infinite` }} />
      ))}
    </div>
  )
}

export default function Chat({ name }: { name: string }) {
  const firstName = name.split(' ')[0]
  const [msgs, setMsgs] = useState<Msg[]>([{
    role: 'assistant',
    content: `Hey ${firstName} 👋 I'm SELLR — your AI sales coach built for Whop.\n\nAsk me anything about your store, pricing, offers, or copy. Specific, real advice — no fluff.\n\nWhat's the biggest problem with your Whop store right now?`,
  }])
  const [input, setInput]     = useState('')
  const [loading, setLoading] = useState(false)
  const [err, setErr]         = useState<string | null>(null)
  const [chips, setChips]     = useState(true)
  const [micOn, setMicOn]     = useState(false)
  const [hasMic, setHasMic]   = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)
  const taRef     = useRef<HTMLTextAreaElement>(null)
  const recRef    = useRef<any>(null)
  const ttsRef    = useRef<SpeechSynthesisUtterance | null>(null)

  useEffect(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (!SR) return
    setHasMic(true)
    const r = new SR()
    r.continuous = false; r.lang = 'en-US'
    r.onresult = (e: any) => { const t = e.results[0]?.[0]?.transcript || ''; if (t) sendMsg(t) }
    r.onend = () => setMicOn(false)
    r.onerror = () => setMicOn(false)
    recRef.current = r
  }, [])

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs, loading])

  const sendMsg = useCallback(async (override?: string) => {
    const text = (override ?? input).trim()
    if (!text || loading) return
    setInput(''); setErr(null); setChips(false)
    if (taRef.current) taRef.current.style.height = 'auto'
    const next: Msg[] = [...msgs, { role: 'user', content: text }]
    setMsgs(next); setLoading(true)
    try {
      const res  = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: next }) })
      const data = await res.json()
      if (!res.ok || data.error) throw new Error(data.error || `Error ${res.status}`)
      setMsgs(p => [...p, { role: 'assistant', content: data.text }])
    } catch (e: any) {
      setErr(e.message || 'Something went wrong. Try again.')
    } finally {
      setLoading(false)
    }
  }, [input, msgs, loading])

  const toggleMic = () => {
    if (!recRef.current) return
    if (micOn) { recRef.current.stop(); setMicOn(false) }
    else { try { recRef.current.start(); setMicOn(true) } catch { setMicOn(false) } }
  }

  const speak = (text: string, btn: HTMLButtonElement) => {
    if (!window.speechSynthesis) return
    if (ttsRef.current) { window.speechSynthesis.cancel(); ttsRef.current = null; btn.textContent = '🔊'; return }
    const u = new SpeechSynthesisUtterance(text.slice(0, 600))
    u.rate = 1.05
    const v = window.speechSynthesis.getVoices().find(v => v.lang === 'en-US')
    if (v) u.voice = v
    u.onend = u.onerror = () => { ttsRef.current = null; btn.textContent = '🔊' }
    ttsRef.current = u
    btn.textContent = '⏹'
    window.speechSynthesis.speak(u)
  }

  const copyText = (text: string, btn: HTMLButtonElement) => {
    navigator.clipboard?.writeText(text).catch(() => {})
    btn.textContent = '✓'
    setTimeout(() => { btn.textContent = '⎘' }, 2000)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#fff', borderRadius: 20, border: '1px solid #e0d8d0', overflow: 'hidden' }}>

      {/* Header */}
      <div style={{ padding: '12px 16px', borderBottom: '1px solid #e0d8d0', display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0, background: '#fff' }}>
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#2a1a14', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 14, flexShrink: 0 }}>S</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: '#2a1a14' }}>SELLR</div>
          <div style={{ fontSize: 11, color: '#8a7a74' }}>AI Sales Coach · Powered by Claude</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'rgba(74,222,128,.09)', color: '#16a34a', padding: '4px 10px', borderRadius: 999, fontSize: 11, fontWeight: 600, flexShrink: 0 }}>
          <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#16a34a', animation: 'ping 2s infinite' }} />
          Live
        </div>
        <button
          onClick={() => { setMsgs([{ role: 'assistant', content: 'Fresh start 🔥 What do you want to work on?' }]); setChips(true); setErr(null) }}
          style={{ padding: '5px 10px', borderRadius: 8, background: 'rgba(42,26,20,.05)', border: '1px solid #e0d8d0', fontSize: 11, color: '#8a7a74', cursor: 'pointer' }}
        >
          Clear
        </button>
      </div>

      {/* Quick chips */}
      {chips && (
        <div style={{ display: 'flex', gap: 6, overflowX: 'auto', padding: '8px 14px', borderBottom: '1px solid #e0d8d0', flexShrink: 0 }}>
          {CHIPS.map((c, i) => (
            <button key={i} onClick={() => { setChips(false); sendMsg(c) }}
              style={{ flexShrink: 0, background: '#e8e4de', border: '1px solid #e0d8d0', borderRadius: 999, padding: '6px 11px', fontSize: 12, color: '#5a3a2e', cursor: 'pointer', whiteSpace: 'nowrap', fontFamily: 'inherit', transition: 'all .15s' }}
              onMouseEnter={e => { const b = e.currentTarget; b.style.background = '#f5e8e0'; b.style.borderColor = '#c4724a'; b.style.color = '#c4724a' }}
              onMouseLeave={e => { const b = e.currentTarget; b.style.background = '#e8e4de'; b.style.borderColor = '#e0d8d0'; b.style.color = '#5a3a2e' }}>
              {c}
            </button>
          ))}
        </div>
      )}

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {msgs.map((m, i) => (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: m.role === 'user' ? 'flex-end' : 'flex-start', gap: 4 }}>
            <div style={{
              maxWidth: '88%', padding: '11px 15px',
              borderRadius: m.role === 'user' ? '18px 18px 3px 18px' : '18px 18px 18px 3px',
              background: m.role === 'user' ? '#2a1a14' : '#e8e4de',
              color: m.role === 'user' ? '#fff' : '#2a1a14',
              fontSize: 14, fontWeight: 300, lineHeight: 1.65,
              border: m.role === 'assistant' ? '1px solid #e0d8d0' : 'none',
              wordBreak: 'break-word', whiteSpace: 'pre-wrap',
              animation: 'msgIn .3s ease',
            }}>
              {m.content}
            </div>
            {m.role === 'assistant' && i > 0 && (
              <div style={{ display: 'flex', gap: 5, marginLeft: 4 }}>
                <button onClick={e => copyText(m.content, e.currentTarget as HTMLButtonElement)}
                  style={{ padding: '3px 9px', borderRadius: 6, background: 'rgba(42,26,20,.06)', border: '1px solid #e0d8d0', fontSize: 11, color: '#8a7a74', cursor: 'pointer', fontFamily: 'inherit' }}>
                  ⎘
                </button>
                <button onClick={e => speak(m.content, e.currentTarget as HTMLButtonElement)}
                  style={{ padding: '3px 9px', borderRadius: 6, background: 'rgba(42,26,20,.06)', border: '1px solid #e0d8d0', fontSize: 11, color: '#8a7a74', cursor: 'pointer', fontFamily: 'inherit' }}>
                  🔊
                </button>
              </div>
            )}
          </div>
        ))}
        {loading && <Dots />}
        {err && (
          <div onClick={() => setErr(null)} style={{ alignSelf: 'center', background: 'rgba(239,68,68,.08)', border: '1px solid rgba(239,68,68,.2)', borderRadius: 12, padding: '9px 14px', fontSize: 13, color: '#dc2626', cursor: 'pointer', textAlign: 'center', maxWidth: '90%', animation: 'msgIn .3s ease' }}>
            ⚠️ {err} · tap to dismiss
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div style={{ padding: '10px 14px', borderTop: '1px solid #e0d8d0', background: '#fff', flexShrink: 0 }}>
        {micOn && <div style={{ textAlign: 'center', fontSize: 12, color: '#c4724a', fontWeight: 500, marginBottom: 6 }}>🎤 Listening...</div>}
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 7 }}>
          <textarea
            ref={taRef} value={input}
            onChange={e => { setInput(e.target.value); e.target.style.height = 'auto'; e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px' }}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMsg() } }}
            placeholder="Ask about your Whop store..." disabled={loading}
            maxLength={800} rows={1}
            style={{ flex: 1, background: '#e8e4de', border: '1.5px solid #e0d8d0', borderRadius: 18, padding: '10px 14px', fontSize: 16, color: '#2a1a14', resize: 'none', outline: 'none', lineHeight: 1.5, minHeight: 42, maxHeight: 120, transition: 'border-color .2s', boxSizing: 'border-box' }}
            onFocus={e => e.target.style.borderColor = '#c4724a'}
            onBlur={e => e.target.style.borderColor = '#e0d8d0'}
          />
          {hasMic && (
            <button onClick={toggleMic}
              style={{ width: 40, height: 40, borderRadius: '50%', background: micOn ? 'rgba(196,114,74,.15)' : '#e8e4de', border: `1.5px solid ${micOn ? '#c4724a' : '#e0d8d0'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0, fontSize: 16, transition: 'all .2s' }}>
              🎤
            </button>
          )}
          <button
            onClick={() => sendMsg()} disabled={loading || !input.trim()}
            style={{ width: 40, height: 40, borderRadius: '50%', background: loading || !input.trim() ? '#ddd8d0' : '#c4724a', border: 'none', color: '#fff', cursor: loading || !input.trim() ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 16, transition: 'all .2s' }}>
            ↑
          </button>
        </div>
        <div style={{ fontSize: 10, color: '#8a7a74', textAlign: 'right', marginTop: 4, fontFamily: "'JetBrains Mono',monospace" }}>
          {input.length}/800 · Enter to send
        </div>
      </div>
    </div>
  )
}
