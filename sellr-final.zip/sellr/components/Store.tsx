'use client'
import { useState } from 'react'

function Spin() {
  return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', gap: 5 }}>
        {[0, 1, 2].map(i => <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: '#c4724a', animation: `dot .72s ease-in-out ${i * .15}s infinite` }} />)}
      </div>
      <div style={{ fontSize: 13, color: '#8a7a74', fontStyle: 'italic' }}>Analyzing your store...</div>
    </div>
  )
}

export default function Store() {
  const [url, setUrl]       = useState('')
  const [desc, setDesc]     = useState('')
  const [result, setResult] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [err, setErr]       = useState<string | null>(null)
  const [copied, setCopied] = useState(false)

  const run = async () => {
    if (!desc.trim()) { setErr('Please describe your store.'); return }
    setErr(null); setLoading(true); setResult(null)
    try {
      const prompt = `Analyze this Whop store:\n\nURL: ${url || 'not provided'}\nDescription: ${desc}\n\nProvide:\n\n**OVERALL SCORE: X/100**\nOne-line verdict.\n\n**TOP 3 REVENUE LEAKS**\nFor each: Problem → Impact → Exact Fix → Est. Revenue Recovery\n\n**QUICK WINS (this week)**\n3 specific things doable in under 2 hours.\n\n**OFFER REVIEW**\nPositioning, price, what is missing.\n\n**GROWTH POTENTIAL**\nEst. monthly revenue increase if all issues are fixed.\n\n→ Next step: The single most important thing to do today.`
      const r = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: prompt }] }) })
      const d = await r.json()
      if (!r.ok || d.error) throw new Error(d.error || 'Error')
      setResult(d.text)
    } catch (e: any) { setErr(e.message) }
    setLoading(false)
  }

  const inpSt: React.CSSProperties = { width: '100%', background: '#e8e4de', border: '1.5px solid #e0d8d0', borderRadius: 12, padding: '10px 14px', fontSize: 16, color: '#2a1a14', outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box', transition: 'border-color .2s' }
  const lbl = (t: string) => <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#5a3a2e', marginBottom: 5, letterSpacing: '.07em', textTransform: 'uppercase' as const }}>{t}</label>

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'clamp(260px,30%,320px) 1fr', gap: 14, height: '100%' }}>
      <div style={{ background: '#fff', borderRadius: 18, border: '1px solid #e0d8d0', padding: 20, overflowY: 'auto' }}>
        <div style={{ fontFamily: "'Fraunces',serif", fontWeight: 700, fontSize: 20, color: '#2a1a14', marginBottom: 4 }}>Store Analyzer</div>
        <div style={{ fontSize: 13, color: '#8a7a74', marginBottom: 18, fontWeight: 300 }}>Instant AI revenue diagnosis for your Whop store.</div>

        <div style={{ marginBottom: 13 }}>
          {lbl('Whop Store URL')}
          <input value={url} onChange={e => setUrl(e.target.value)} type="text" placeholder="whop.com/your-store" style={inpSt} onFocus={e => e.target.style.borderColor = '#c4724a'} onBlur={e => e.target.style.borderColor = '#e0d8d0'} />
        </div>
        <div style={{ marginBottom: 18 }}>
          {lbl('Describe Your Store')}
          <textarea value={desc} onChange={e => setDesc(e.target.value)} rows={8} placeholder="What do you sell? Who is your audience? Price? Conversion rate? Current problems?" style={{ ...inpSt, resize: 'vertical', lineHeight: 1.5, minHeight: 140 } as any} onFocus={e => e.target.style.borderColor = '#c4724a'} onBlur={e => e.target.style.borderColor = '#e0d8d0'} />
        </div>

        {err && <div onClick={() => setErr(null)} style={{ padding: '9px 13px', borderRadius: 10, background: 'rgba(239,68,68,.08)', border: '1px solid rgba(239,68,68,.2)', color: '#dc2626', fontSize: 13, marginBottom: 12, cursor: 'pointer' }}>⚠️ {err}</div>}
        <button onClick={run} disabled={loading || !desc.trim()} style={{ width: '100%', padding: 13, borderRadius: 999, background: loading || !desc.trim() ? '#ddd8d0' : '#2a1a14', color: '#fff', fontWeight: 700, fontSize: 14.5, border: 'none', cursor: loading || !desc.trim() ? 'not-allowed' : 'pointer', fontFamily: 'inherit' }}>
          {loading ? 'Analyzing...' : 'Analyze My Store →'}
        </button>
      </div>

      <div style={{ background: '#fff', borderRadius: 18, border: '1px solid #e0d8d0', padding: 20, display: 'flex', flexDirection: 'column', overflowY: 'auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexShrink: 0 }}>
          <div style={{ fontFamily: "'Fraunces',serif", fontWeight: 700, fontSize: 20, color: '#2a1a14' }}>Analysis Report</div>
          {result && (
            <button onClick={() => { navigator.clipboard?.writeText(result).catch(() => {}); setCopied(true); setTimeout(() => setCopied(false), 2000) }}
              style={{ padding: '4px 10px', borderRadius: 7, background: copied ? 'rgba(74,222,128,.1)' : 'rgba(42,26,20,.06)', border: `1px solid ${copied ? 'rgba(74,222,128,.3)' : '#e0d8d0'}`, fontSize: 11, color: copied ? '#16a34a' : '#8a7a74', cursor: 'pointer', fontFamily: 'inherit' }}>
              {copied ? '✓ Copied' : '⎘ Copy'}
            </button>
          )}
        </div>
        {loading && <Spin />}
        {result && !loading && <div style={{ fontSize: 13.5, color: '#2a1a14', lineHeight: 1.8, whiteSpace: 'pre-wrap', fontWeight: 300 }}>{result}</div>}
        {!result && !loading && <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><div style={{ fontFamily: "'Fraunces',serif", fontStyle: 'italic', fontSize: 18, color: 'rgba(42,26,20,.18)', textAlign: 'center' }}>Your report appears here</div></div>}
      </div>
    </div>
  )
}
