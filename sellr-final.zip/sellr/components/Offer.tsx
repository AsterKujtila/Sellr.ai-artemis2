'use client'
import { useState } from 'react'

const STYLES = ['bold', 'soft', 'urgency', 'story']

function Spin() {
  return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', gap: 5 }}>
        {[0, 1, 2].map(i => <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: '#c4724a', animation: `dot .72s ease-in-out ${i * .15}s infinite` }} />)}
      </div>
      <div style={{ fontSize: 13, color: '#8a7a74', fontStyle: 'italic' }}>Writing your offer...</div>
    </div>
  )
}

export default function Offer() {
  const [style, setStyle]   = useState('bold')
  const [result, setResult] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [err, setErr]       = useState<string | null>(null)
  const [copied, setCopied] = useState(false)

  const run = async () => {
    const prod  = (document.getElementById('op') as HTMLInputElement)?.value.trim()
    const aud   = (document.getElementById('oa') as HTMLTextAreaElement)?.value.trim()
    const out   = (document.getElementById('oo') as HTMLInputElement)?.value.trim()
    const price = (document.getElementById('opr') as HTMLInputElement)?.value.trim()
    if (!prod) { setErr('Product name is required.'); return }
    setErr(null); setLoading(true); setResult(null)
    try {
      const prompt = `Write a complete high-converting Whop offer page:\n\nProduct: ${prod}\nAudience: ${aud || 'not specified'}\nOutcome: ${out || 'not specified'}\nPrice: ${price || 'not specified'}\nStyle: ${style}\n\nProvide:\n\n**HEADLINE** (under 10 words)\n\n**SUBHEADLINE** (1 sentence)\n\n**BULLET POINTS** (5x starting with ✓)\n\n**CTA BUTTON** (under 6 words)\n\n**TRUST LINE** (guarantee or social proof)\n\n---\n**CRITIQUE:** What is strongest, and best A/B test to run first.`
      const r = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: prompt }] }) })
      const d = await r.json()
      if (!r.ok || d.error) throw new Error(d.error || 'Error')
      setResult(d.text)
    } catch (e: any) { setErr(e.message) }
    setLoading(false)
  }

  const inpSt: React.CSSProperties = { width: '100%', background: '#e8e4de', border: '1.5px solid #e0d8d0', borderRadius: 12, padding: '10px 14px', fontSize: 16, color: '#2a1a14', outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box', transition: 'border-color .2s' }
  const lbl = (t: string) => <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#5a3a2e', marginBottom: 5, letterSpacing: '.07em', textTransform: 'uppercase' as const }}>{t}</label>

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'clamp(260px,30%,320px) 1fr', gap: 14, height: '100%' }}>
      <div style={{ background: '#fff', borderRadius: 18, border: '1px solid #e0d8d0', padding: 20, overflowY: 'auto' }}>
        <div style={{ fontFamily: "'Fraunces',serif", fontWeight: 700, fontSize: 20, color: '#2a1a14', marginBottom: 4 }}>Offer Builder</div>
        <div style={{ fontSize: 13, color: '#8a7a74', marginBottom: 18, fontWeight: 300 }}>SELLR writes your complete offer copy.</div>

        <div style={{ marginBottom: 13 }}>{lbl('Product / Service')}<input id="op" type="text" placeholder="e.g. Fitness coaching community" style={inpSt} onFocus={e => e.target.style.borderColor = '#c4724a'} onBlur={e => e.target.style.borderColor = '#e0d8d0'} /></div>
        <div style={{ marginBottom: 13 }}>{lbl('Target Audience')}<textarea id="oa" rows={2} placeholder="e.g. Online coaches under $5k/mo" style={{ ...inpSt, resize: 'vertical', lineHeight: 1.5, minHeight: 72 } as any} onFocus={e => e.target.style.borderColor = '#c4724a'} onBlur={e => e.target.style.borderColor = '#e0d8d0'} /></div>
        <div style={{ marginBottom: 13 }}>{lbl('Main Outcome')}<input id="oo" type="text" placeholder="e.g. Double revenue in 60 days" style={inpSt} onFocus={e => e.target.style.borderColor = '#c4724a'} onBlur={e => e.target.style.borderColor = '#e0d8d0'} /></div>
        <div style={{ marginBottom: 16 }}>{lbl('Price Point')}<input id="opr" type="text" placeholder="e.g. $47/mo, $197 one-time" style={inpSt} onFocus={e => e.target.style.borderColor = '#c4724a'} onBlur={e => e.target.style.borderColor = '#e0d8d0'} /></div>

        <div style={{ marginBottom: 18 }}>
          {lbl('Copy Style')}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7 }}>
            {STYLES.map(s => (
              <button key={s} onClick={() => setStyle(s)} style={{ padding: '9px 6px', borderRadius: 10, fontFamily: 'inherit', border: `1.5px solid ${style === s ? '#c4724a' : '#e0d8d0'}`, background: style === s ? '#f5e8e0' : '#e8e4de', color: style === s ? '#c4724a' : '#8a7a74', fontSize: 13, fontWeight: 500, cursor: 'pointer', textTransform: 'capitalize', transition: 'all .15s' }}>
                {s}
              </button>
            ))}
          </div>
        </div>

        {err && <div onClick={() => setErr(null)} style={{ padding: '9px 13px', borderRadius: 10, background: 'rgba(239,68,68,.08)', border: '1px solid rgba(239,68,68,.2)', color: '#dc2626', fontSize: 13, marginBottom: 12, cursor: 'pointer' }}>⚠️ {err}</div>}
        <button onClick={run} disabled={loading} style={{ width: '100%', padding: 13, borderRadius: 999, background: loading ? '#ddd8d0' : '#c4724a', color: '#fff', fontWeight: 700, fontSize: 14.5, border: 'none', cursor: loading ? 'not-allowed' : 'pointer', transition: 'all .2s', fontFamily: 'inherit' }}>
          {loading ? 'Writing...' : 'Generate Offer Copy →'}
        </button>
      </div>

      <div style={{ background: '#fff', borderRadius: 18, border: '1px solid #e0d8d0', padding: 20, display: 'flex', flexDirection: 'column', overflowY: 'auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexShrink: 0 }}>
          <div style={{ fontFamily: "'Fraunces',serif", fontWeight: 700, fontSize: 20, color: '#2a1a14' }}>Generated Copy</div>
          {result && (
            <button onClick={() => { navigator.clipboard?.writeText(result).catch(() => {}); setCopied(true); setTimeout(() => setCopied(false), 2000) }}
              style={{ padding: '4px 10px', borderRadius: 7, background: copied ? 'rgba(74,222,128,.1)' : 'rgba(42,26,20,.06)', border: `1px solid ${copied ? 'rgba(74,222,128,.3)' : '#e0d8d0'}`, fontSize: 11, color: copied ? '#16a34a' : '#8a7a74', cursor: 'pointer', fontFamily: 'inherit' }}>
              {copied ? '✓ Copied' : '⎘ Copy'}
            </button>
          )}
        </div>
        {loading && <Spin />}
        {result && !loading && <div style={{ fontSize: 13.5, color: '#2a1a14', lineHeight: 1.8, whiteSpace: 'pre-wrap', fontWeight: 300 }}>{result}</div>}
        {!result && !loading && (
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 6 }}>
            <div style={{ fontFamily: "'Fraunces',serif", fontStyle: 'italic', fontSize: 18, color: 'rgba(42,26,20,.18)', textAlign: 'center' }}>Your offer copy appears here</div>
            <div style={{ fontSize: 12, color: 'rgba(42,26,20,.12)' }}>Fill the form and click Generate</div>
          </div>
        )}
      </div>
    </div>
  )
}
