import Anthropic from '@anthropic-ai/sdk'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { NextRequest, NextResponse } from 'next/server'

const claude = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

const SYSTEM = `You are SELLR — an elite AI sales coach built exclusively for Whop sellers.

PERSONALITY: Direct, sharp, warm. Like a world-class sales consultant who genuinely cares. Always give specific, actionable advice.

EXPERTISE: Whop platform, offer copywriting, conversion optimization, pricing strategy, launch planning, store analysis, A/B testing, community growth.

RULES:
- Be hyper-specific, never vague
- Keep responses scannable with short paragraphs  
- Give honest critique with exact rewrites when shown copy
- End every response with "→ Next step:" + one clear action
- Max 300 words unless asked for more`

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let messages: { role: 'user' | 'assistant'; content: string }[]
  try {
    const body = await req.json()
    messages = body.messages
    if (!Array.isArray(messages) || messages.length === 0) throw new Error()
  } catch {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 })
  }

  try {
    const response = await claude.messages.create({
      model: 'claude-opus-4-6',
      max_tokens: 1024,
      system: SYSTEM,
      messages: messages.map(m => ({
        role: m.role,
        content: String(m.content).slice(0, 4000),
      })),
    })

    const text = response.content[0]?.type === 'text' ? response.content[0].text : ''
    return NextResponse.json({ text })
  } catch (err: any) {
    console.error('Claude error:', err?.message)
    return NextResponse.json({ error: err?.message || 'API error' }, { status: 500 })
  }
}
