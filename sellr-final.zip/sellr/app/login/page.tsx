'use client'
import { signIn, useSession } from 'next-auth/react'
import { useRouter, useSearchParams } from 'next/navigation'
import { useState, useEffect, Suspense } from 'react'

function Login() {
  const { status } = useSession()
  const router = useRouter()
  const params = useSearchParams()
  const [email, setEmail] = useState('')
  const [pass, setPass] = useState('')
  const [err, setErr] = useState('')
  const [gLoad, setGLoad] = useState(false)
  const [eLoad, setELoad] = useState(false)

  useEffect(() => {
    if (status === 'authenticated') router.push('/dashboard')
  }, [status, router])

  useEffect(() => {
    const e = params.get('error')
    if (e === 'OAuthAccountNotLinked') setErr('Email already used with another provider.')
    else if (e) setErr('Sign in failed — please try again.')
  }, [params])

  const googleLogin = async () => {
    setGLoad(true)
    setErr('')
    await signIn('google', { callbackUrl: '/dashboard' })
  }

  const emailLogin = async (ev: React.FormEvent) => {
    ev.preventDefault()
    setErr('')
    if (!email.includes('@')) { setErr('Enter a valid email.'); return }
    if (pass.length < 4) { setErr('Password must be 4+ characters.'); return }
    setELoad(true)
    const r = await signIn('credentials', { email, password: pass, redirect: false })
    if (r?.error) { setErr('Invalid credentials.'); setELoad(false) }
    else router.push('/dashboard')
  }

  if (status === 'loading') {
    return (
      <div style={{ minHeight: '100dvh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#2d3a45' }}>
        <div style={{ width: 36, height: 36, border: '3px solid rgba(255,255,255,.15)', borderTopColor: '#c4724a', borderRadius: '50%', animation: 'spin .7s linear infinite' }} />
      </div>
    )
  }

  return (
    <div style={{ minHeight: '100dvh', background: '#2d3a45', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, position: 'relative', overflow: 'hidden' }}>
      {/* bg orbs */}
      <div style={{ position: 'absolute', top: -180, right: -120, width: 500, height: 500, borderRadius: '50%', background: 'radial-gradient(ellipse,rgba(196,114,74,.12),transparent 70%)', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', bottom: -120, left: -160, width: 440, height: 440, borderRadius: '50%', background: 'radial-gradient(ellipse,rgba(240,237,232,.05),transparent 70%)', pointerEvents: 'none' }} />

      <div style={{ background: '#fff', borderRadius: 28, padding: '36px 28px', width: '100%', maxWidth: 390, boxShadow: '0 40px 80px rgba(0,0,0,.3)', position: 'relative', zIndex: 1, animation: 'fadeIn .5s ease' }}>
        {/* logo */}
        <div style={{ fontWeight: 700, fontSize: 22, color: '#2a1a14', marginBottom: 6 }}>
          sellr<span style={{ color: '#c4724a', fontWeight: 300 }}>.ai</span>
        </div>
        <div style={{ fontSize: 14, fontWeight: 300, color: '#8a7a74', marginBottom: 26 }}>
          Sign in to your AI sales dashboard
        </div>

        {/* error */}
        {err && (
          <div style={{ padding: '10px 14px', borderRadius: 10, background: 'rgba(239,68,68,.08)', border: '1px solid rgba(239,68,68,.2)', color: '#dc2626', fontSize: 13, marginBottom: 16 }}>
            {err}
          </div>
        )}

        {/* Google button */}
        <button
          onClick={googleLogin}
          disabled={gLoad || eLoad}
          style={{
            width: '100%', padding: '13px 16px', borderRadius: 14,
            background: '#fff', border: '1.5px solid #e0d8d0',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
            fontWeight: 600, fontSize: 15, color: '#2a1a14',
            cursor: gLoad ? 'not-allowed' : 'pointer',
            transition: 'all .2s', marginBottom: 14,
            opacity: gLoad ? .65 : 1,
          }}
        >
          {gLoad ? (
            <div style={{ width: 18, height: 18, border: '2px solid #e0d8d0', borderTopColor: '#c4724a', borderRadius: '50%', animation: 'spin .7s linear infinite' }} />
          ) : (
            <svg width="18" height="18" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
            </svg>
          )}
          {gLoad ? 'Connecting to Google...' : 'Continue with Google'}
        </button>

        {/* divider */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14, color: '#8a7a74', fontSize: 12 }}>
          <div style={{ flex: 1, height: 1, background: '#e0d8d0' }} />
          or sign in with email
          <div style={{ flex: 1, height: 1, background: '#e0d8d0' }} />
        </div>

        {/* email form */}
        <form onSubmit={emailLogin}>
          <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#5a3a2e', marginBottom: 5, letterSpacing: '.07em', textTransform: 'uppercase' }}>Email</label>
          <input
            type="email" value={email} onChange={e => setEmail(e.target.value)}
            placeholder="your@email.com" autoComplete="email"
            style={{ width: '100%', background: '#e8e4de', border: '1.5px solid #e0d8d0', borderRadius: 12, padding: '12px 16px', fontSize: 16, color: '#2a1a14', outline: 'none', marginBottom: 12, display: 'block', transition: 'border-color .2s', boxSizing: 'border-box' }}
            onFocus={e => e.target.style.borderColor = '#c4724a'}
            onBlur={e => e.target.style.borderColor = '#e0d8d0'}
          />

          <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#5a3a2e', marginBottom: 5, letterSpacing: '.07em', textTransform: 'uppercase' }}>Password</label>
          <input
            type="password" value={pass} onChange={e => setPass(e.target.value)}
            placeholder="••••••••" autoComplete="current-password"
            style={{ width: '100%', background: '#e8e4de', border: '1.5px solid #e0d8d0', borderRadius: 12, padding: '12px 16px', fontSize: 16, color: '#2a1a14', outline: 'none', marginBottom: 18, display: 'block', transition: 'border-color .2s', boxSizing: 'border-box' }}
            onFocus={e => e.target.style.borderColor = '#c4724a'}
            onBlur={e => e.target.style.borderColor = '#e0d8d0'}
          />

          <button
            type="submit" disabled={eLoad || gLoad}
            style={{ width: '100%', padding: 14, borderRadius: 999, background: eLoad ? '#ddd8d0' : '#2a1a14', color: '#fff', fontWeight: 700, fontSize: 15, cursor: eLoad ? 'not-allowed' : 'pointer', transition: 'all .2s', marginBottom: 16, border: 'none' }}
          >
            {eLoad ? 'Signing in...' : 'Sign in →'}
          </button>
        </form>

        <div style={{ textAlign: 'center', fontSize: 12, color: '#8a7a74' }}>
          No account?{' '}
          <span style={{ color: '#c4724a', fontWeight: 600, cursor: 'pointer' }} onClick={googleLogin}>
            Start free with Google →
          </span>
        </div>

        <div style={{ marginTop: 14, padding: '9px 13px', background: '#e8e4de', borderRadius: 10, fontSize: 11.5, color: '#8a7a74' }}>
          <strong style={{ color: '#2a1a14' }}>Demo:</strong> any email + any password (4+ chars)
        </div>
      </div>
    </div>
  )
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div style={{ minHeight: '100dvh', background: '#2d3a45' }} />}>
      <Login />
    </Suspense>
  )
}
