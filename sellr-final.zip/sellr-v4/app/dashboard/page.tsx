'use client'
import { useSession, signOut } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useState, useEffect } from 'react'
import dynamic from 'next/dynamic'

const Chat  = dynamic(() => import('@/components/Chat'),  { ssr:false })
const Offer = dynamic(() => import('@/components/Offer'), { ssr:false })
const Store = dynamic(() => import('@/components/Store'), { ssr:false })

const T = { cr:'#f0ede8',cr2:'#e8e4de',cr3:'#ddd8d0',br:'#2a1a14',br2:'#5a3a2e',br3:'#8a7a74',tr:'#c4724a',tr2:'#e8956d',trs:'#f5e8e0',bd:'#e0d8d0',hero:'#2d3a45',ft:'#1a0a08' }

const NAV = [
  { id:'dashboard', ic:'⊞', label:'Dashboard'     },
  { id:'chat',      ic:'💬', label:'AI Chat'        },
  { id:'offers',    ic:'✍️',  label:'Offer Builder'  },
  { id:'store',     ic:'🔍', label:'Store Analyzer'  },
  { id:'credits',   ic:'⚡', label:'Credits'         },
]

const KPIS = [
  { l:'Revenue (7d)', v:'$4,280', t:'+12.4%', d:[45,33,55,79,67,90,100] },
  { l:'Orders',       v:'847',    t:'+8.1%',  d:[60,45,70,80,75,88,95]  },
  { l:'Conversion',   v:'3.8%',   t:'+0.4%',  d:[30,28,35,38,36,40,42]  },
  { l:'Store Score',  v:'82/100', t:'+5pts',  d:[65,68,70,74,77,80,82]  },
]

function Credits() {
  const plans = [
    { n:'Starter', p:19, cr:200, feats:['Store Analyzer','Offer Builder','AI Chat','A/B Tester','Never expires'], hot:false },
    { n:'Pro',     p:49, cr:600, feats:['Everything in Starter','Launch Builder','Unlimited history','Priority support','Early features'], hot:true },
    { n:'Scale',   p:99, cr:1500,feats:['Everything in Pro','Founder access','PDF reports','Custom integrations','1:1 onboarding'], hot:false },
  ]
  return (
    <div style={{display:'flex',flexDirection:'column',gap:14,overflowY:'auto'}}>
      <div style={{background:'#fff',borderRadius:18,border:`1px solid ${T.bd}`,padding:20}}>
        <div style={{fontFamily:"'Fraunces',serif",fontWeight:700,fontSize:20,color:T.br,marginBottom:4}}>Credits & Billing</div>
        <div style={{fontSize:13,color:T.br3,marginBottom:16,fontWeight:300}}>Credits power all AI features and never expire.</div>
        <div style={{display:'flex',alignItems:'center',gap:18,flexWrap:'wrap',marginBottom:14}}>
          <div><div style={{fontSize:11,color:T.br3,marginBottom:2}}>Credits remaining</div><div style={{display:'flex',alignItems:'baseline',gap:4}}><span style={{fontFamily:"'Fraunces',serif",fontWeight:900,fontSize:46,color:T.tr}}>18</span><span style={{fontSize:14,color:T.br3}}>/ 20</span></div></div>
        </div>
        <div style={{background:T.cr2,borderRadius:11,padding:'10px 14px',fontSize:12.5,color:T.br2}}><strong style={{color:T.br}}>Credit costs:</strong> AI Chat = 1 · Offer Builder = 2 · Store Analyzer = 3</div>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',gap:11}}>
        {plans.map(p=>(
          <div key={p.n} style={{background:p.hot?T.br:'#fff',borderRadius:18,padding:'20px 18px',border:`1px solid ${p.hot?'rgba(255,255,255,.1)':T.bd}`,position:'relative',transition:'transform .25s,box-shadow .25s',cursor:'default'}}
            onMouseEnter={e=>{e.currentTarget.style.transform='translateY(-3px)';e.currentTarget.style.boxShadow='0 12px 36px rgba(42,26,20,.10)'}}
            onMouseLeave={e=>{e.currentTarget.style.transform='none';e.currentTarget.style.boxShadow='none'}}>
            {p.hot&&<div style={{position:'absolute',top:-10,left:'50%',transform:'translateX(-50%)',background:T.tr,color:'#fff',fontSize:9,fontWeight:700,padding:'3px 10px',borderRadius:999,letterSpacing:'.1em',whiteSpace:'nowrap'}}>BEST VALUE</div>}
            <div style={{fontSize:10,fontWeight:700,letterSpacing:'.08em',textTransform:'uppercase',marginBottom:8,color:p.hot?'rgba(255,255,255,.45)':T.br3}}>{p.n}</div>
            <div style={{fontFamily:"'Fraunces',serif",fontWeight:900,fontSize:38,marginBottom:2,color:p.hot?'#fff':T.br}}>${p.p}</div>
            <div style={{fontSize:11,marginBottom:12,color:p.hot?'rgba(255,255,255,.35)':T.br3}}>one-time · never expires</div>
            <div style={{background:p.hot?'rgba(255,255,255,.07)':'rgba(42,26,20,.04)',borderRadius:9,padding:'7px 11px',fontSize:12.5,marginBottom:14,color:p.hot?'rgba(255,255,255,.7)':T.br2}}>⚡ {p.cr} credits</div>
            {p.feats.map((f,j)=><div key={j} style={{display:'flex',alignItems:'center',gap:6,padding:'4px 0',fontSize:12,borderBottom:j<p.feats.length-1?`1px solid ${p.hot?'rgba(255,255,255,.06)':T.bd}`:'none',color:p.hot?'rgba(255,255,255,.6)':T.br2}}><span style={{color:T.tr}}>✓</span>{f}</div>)}
            <button style={{width:'100%',padding:11,borderRadius:999,fontFamily:'inherit',background:p.hot?T.tr:'transparent',color:p.hot?'#fff':T.br,border:p.hot?'none':`1.5px solid ${T.bd}`,fontWeight:700,fontSize:13.5,cursor:'pointer',marginTop:14,transition:'opacity .2s'}}>Get {p.n} →</button>
          </div>
        ))}
      </div>
    </div>
  )
}

export default function Dashboard() {
  const { data: session, status } = useSession()
  const router  = useRouter()
  const [view, setView]   = useState('dashboard')
  const [mobSb, setMobSb] = useState(false)
  const [isMob, setIsMob] = useState(false)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login')
    const chk = () => setIsMob(window.innerWidth < 768)
    chk(); window.addEventListener('resize', chk)
    return () => window.removeEventListener('resize', chk)
  }, [status, router])

  if (status === 'loading' || !session) return (
    <div style={{minHeight:'100dvh',display:'flex',alignItems:'center',justifyContent:'center',background:T.cr}}>
      <div style={{width:36,height:36,border:`3px solid ${T.bd}`,borderTopColor:T.tr,borderRadius:'50%',animation:'spin .7s linear infinite'}}/>
    </div>
  )

  const u       = session.user!
  const uName   = u.name || u.email || 'there'
  const initials = uName.slice(0,2).toUpperCase()
  const short    = uName.split(' ')[0]
  const nav = (v:string) => { setView(v); setMobSb(false) }

  /* ── Sidebar ── */
  const SB = () => (
    <div style={{width:isMob?240:210,background:T.ft,display:'flex',flexDirection:'column',padding:'16px 10px',height:'100dvh',flexShrink:0}}>
      <div style={{padding:'4px 8px 14px',borderBottom:'1px solid rgba(255,255,255,.07)',marginBottom:10}}>
        <div style={{fontWeight:700,fontSize:16,color:'#fff'}}>sellr<span style={{color:T.tr,fontWeight:300}}>.ai</span></div>
        <div style={{fontSize:9.5,color:'rgba(255,255,255,.28)',marginTop:2}}>AI Sales Coach</div>
      </div>
      <div style={{flex:1}}>
        {NAV.map(n=>(
          <button key={n.id} onClick={()=>nav(n.id)} style={{width:'100%',display:'flex',alignItems:'center',gap:9,padding:'10px 12px',borderRadius:11,marginBottom:2,border:'none',cursor:'pointer',fontFamily:'inherit',textAlign:'left',background:view===n.id?'rgba(196,114,74,.12)':'transparent',color:view===n.id?T.tr:'rgba(255,255,255,.38)',fontSize:13.5,fontWeight:view===n.id?600:400,transition:'all .16s'}}
            onMouseEnter={e=>{if(view!==n.id){(e.currentTarget as HTMLButtonElement).style.background='rgba(255,255,255,.04)';(e.currentTarget as HTMLButtonElement).style.color='rgba(255,255,255,.7)'}}}
            onMouseLeave={e=>{if(view!==n.id){(e.currentTarget as HTMLButtonElement).style.background='transparent';(e.currentTarget as HTMLButtonElement).style.color='rgba(255,255,255,.38)'}}}>
            <span style={{fontSize:14}}>{n.ic}</span>{n.label}
          </button>
        ))}
      </div>
      <div style={{borderTop:'1px solid rgba(255,255,255,.07)',paddingTop:13,display:'flex',alignItems:'center',gap:9}}>
        <div style={{width:36,height:36,borderRadius:'50%',background:'rgba(42,26,20,.8)',border:'3px solid rgba(196,114,74,.4)',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700,fontSize:11,color:'#fff',flexShrink:0}}>18</div>
        <div><div style={{fontSize:11.5,color:'rgba(255,255,255,.5)',fontWeight:500}}>18 credits</div><button onClick={()=>nav('credits')} style={{fontSize:11,color:T.tr,background:'none',border:'none',cursor:'pointer',fontFamily:'inherit',fontWeight:500,padding:0}}>Get more →</button></div>
      </div>
    </div>
  )

  /* ── Dashboard home ── */
  const Home = () => (
    <div style={{display:'flex',flexDirection:'column',gap:14}}>
      {/* Hero */}
      <div style={{background:`linear-gradient(135deg,${T.hero},#1e2d38)`,borderRadius:18,padding:isMob?'16px':'22px',position:'relative',overflow:'hidden'}}>
        <div style={{position:'absolute',top:-50,right:-50,width:160,height:160,borderRadius:'50%',background:'radial-gradient(ellipse,rgba(196,114,74,.16),transparent 70%)',pointerEvents:'none'}}/>
        <div style={{fontFamily:"'Fraunces',serif",fontWeight:300,fontSize:isMob?19:25,color:'#fff',marginBottom:5}}>Hey, {short} 👋</div>
        <div style={{fontSize:13,fontWeight:300,color:'rgba(240,237,232,.6)',marginBottom:16}}>Revenue up 12.4% this week. SELLR found 3 new opportunities.</div>
        <button onClick={()=>nav('chat')} style={{display:'inline-flex',alignItems:'center',gap:6,background:T.tr,color:'#fff',padding:'9px 18px',borderRadius:999,border:'none',fontWeight:700,fontSize:14,cursor:'pointer',fontFamily:'inherit',transition:'opacity .2s'}}
          onMouseEnter={e=>{(e.currentTarget as HTMLButtonElement).style.opacity='.85'}}
          onMouseLeave={e=>{(e.currentTarget as HTMLButtonElement).style.opacity='1'}}>
          💬 Ask SELLR now
        </button>
      </div>

      {/* KPIs */}
      <div style={{display:'grid',gridTemplateColumns:isMob?'1fr 1fr':'repeat(4,1fr)',gap:11}}>
        {KPIS.map(k=>{
          const max=Math.max(...k.d)
          return (
            <div key={k.l} style={{background:'#fff',borderRadius:15,border:`1px solid ${T.bd}`,padding:13,transition:'transform .25s,box-shadow .25s',cursor:'default'}}
              onMouseEnter={e=>{e.currentTarget.style.transform='translateY(-2px)';e.currentTarget.style.boxShadow='0 6px 20px rgba(42,26,20,.07)'}}
              onMouseLeave={e=>{e.currentTarget.style.transform='none';e.currentTarget.style.boxShadow='none'}}>
              <div style={{fontSize:10,color:T.br3,marginBottom:2}}>{k.l}</div>
              <div style={{fontFamily:"'Fraunces',serif",fontWeight:700,fontSize:21,color:T.br,letterSpacing:'-.02em',marginBottom:2}}>{k.v}</div>
              <div style={{display:'inline-flex',alignItems:'center',gap:2,background:'rgba(74,222,128,.10)',color:'#16a34a',padding:'2px 6px',borderRadius:999,fontSize:9.5,fontWeight:600,marginBottom:8}}>↑ {k.t}</div>
              <div style={{display:'flex',alignItems:'flex-end',gap:2,height:30}}>
                {k.d.map((v,i)=><div key={i} style={{flex:1,background:`linear-gradient(180deg,${T.tr},${T.tr}22)`,borderRadius:'2px 2px 0 0',height:`${Math.round((v/max)*100)}%`,opacity:i===k.d.length-1?1:0.44+i*0.07}}/>)}
              </div>
            </div>
          )
        })}
      </div>

      {/* Quick + Activity */}
      <div style={{display:'grid',gridTemplateColumns:isMob?'1fr':'1fr 1fr',gap:13}}>
        <div style={{background:'#fff',borderRadius:18,border:`1px solid ${T.bd}`,padding:18}}>
          <div style={{fontFamily:"'Fraunces',serif",fontWeight:700,fontSize:16,color:T.br,marginBottom:13}}>Quick Actions</div>
          {[
            {ic:'💬',l:'Ask SELLR',s:'Instant sales advice',bg:T.br,to:'chat'},
            {ic:'✍️',l:'Write an Offer',s:'AI-generated copy',bg:T.tr,to:'offers'},
            {ic:'🔍',l:'Analyze Store',s:'Find revenue leaks',bg:T.hero,to:'store'},
          ].map(a=>(
            <button key={a.to} onClick={()=>nav(a.to)} style={{display:'flex',alignItems:'center',gap:10,padding:'11px 13px',borderRadius:13,background:T.cr2,border:`1px solid ${T.bd}`,cursor:'pointer',width:'100%',marginBottom:7,fontFamily:'inherit',textAlign:'left',transition:'all .18s'}}
              onMouseEnter={e=>{e.currentTarget.style.background=T.trs;e.currentTarget.style.borderColor=T.tr}}
              onMouseLeave={e=>{e.currentTarget.style.background=T.cr2;e.currentTarget.style.borderColor=T.bd}}>
              <div style={{width:33,height:33,borderRadius:9,background:a.bg,display:'flex',alignItems:'center',justifyContent:'center',fontSize:14,flexShrink:0}}>{a.ic}</div>
              <div><div style={{fontWeight:600,fontSize:13,color:T.br}}>{a.l}</div><div style={{fontSize:11,color:T.br3,marginTop:1}}>{a.s}</div></div>
            </button>
          ))}
        </div>
        <div style={{background:'#fff',borderRadius:18,border:`1px solid ${T.bd}`,padding:18}}>
          <div style={{fontFamily:"'Fraunces',serif",fontWeight:700,fontSize:16,color:T.br,marginBottom:13}}>Recent Activity</div>
          {[
            {dot:T.tr, t:'New order: "Elite Bundle"', d:'$47', tm:'2m ago'},
            {dot:'#4ade80',t:'Checkout optimized → CTR +8%',tm:'14m ago'},
            {dot:'#60a5fa',t:'Store score: 82/100',tm:'1h ago'},
            {dot:T.tr2,t:'3 offer variants generated',tm:'2h ago'},
          ].map((a,i,arr)=>(
            <div key={i} style={{display:'flex',alignItems:'center',gap:8,padding:'8px 0',borderBottom:i<arr.length-1?`1px solid ${T.bd}`:'none'}}>
              <div style={{width:6,height:6,borderRadius:'50%',background:a.dot,flexShrink:0}}/>
              <div style={{flex:1,fontSize:12,color:T.br2,lineHeight:1.4}}>{a.t}{(a as any).d&&<strong style={{color:T.br}}> {(a as any).d}</strong>}</div>
              <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:T.br3,flexShrink:0}}>{a.tm}</div>
            </div>
          ))}
          <div style={{marginTop:11,paddingTop:9,borderTop:`1px solid ${T.bd}`,display:'inline-flex',gap:4}}>
            {[0,1,2].map(i=><div key={i} style={{width:5,height:5,borderRadius:'50%',background:T.tr,animation:`dot .72s ease-in-out infinite ${i*.15}s`}}/>)}
          </div>
        </div>
      </div>

      {/* Insight */}
      <div style={{background:T.trs,border:'1px solid rgba(196,114,74,.2)',borderRadius:15,padding:'13px 17px',display:'flex',alignItems:'center',gap:12,flexWrap:'wrap'}}>
        <div style={{width:32,height:32,borderRadius:9,background:T.tr,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,fontSize:15}}>⚡</div>
        <div style={{flex:1,minWidth:160}}><div style={{fontWeight:600,fontSize:13,color:T.br,marginBottom:2}}>💡 SELLR Insight</div><div style={{fontSize:12.5,color:T.br2,fontWeight:300}}>Checkout losing 34% at step 2. Add a trust section → +$840/mo est.</div></div>
        <button onClick={()=>nav('chat')} style={{background:T.tr,color:'#fff',padding:'7px 14px',borderRadius:999,border:'none',fontWeight:600,fontSize:12.5,cursor:'pointer',fontFamily:'inherit',flexShrink:0}}>Fix it →</button>
      </div>
    </div>
  )

  const views: Record<string, React.ReactNode> = {
    dashboard: <Home/>,
    chat:      <Chat  name={uName}/>,
    offers:    <Offer/>,
    store:     <Store/>,
    credits:   <Credits/>,
  }

  return (
    <>
      <style>{`
        @keyframes dot{0%,100%{transform:translateY(0) scale(1);opacity:.4}50%{transform:translateY(-5px) scale(1.15);opacity:1}}
        @keyframes ping{0%{transform:scale(1);opacity:.6}100%{transform:scale(2.2);opacity:0}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes msgIn{from{opacity:0;transform:translateY(8px) scale(.97)}to{opacity:1;transform:none}}
        @keyframes slideIn{from{transform:translateX(-100%)}to{transform:none}}
        @keyframes orb{0%,100%{transform:scale(1) translate(0,0)}33%{transform:scale(1.06) translate(2%,-3%)}66%{transform:scale(.97) translate(-2%,2%)}}
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:3px;height:3px}
        ::-webkit-scrollbar-thumb{background:#e0d8d0;border-radius:9px}
      `}</style>

      <div style={{display:'flex',height:'100dvh',overflow:'hidden',background:T.cr}}>
        {/* Desktop sidebar */}
        {!isMob && <SB/>}

        {/* Mobile overlay + sidebar */}
        {isMob && mobSb && (
          <>
            <div onClick={()=>setMobSb(false)} style={{position:'fixed',inset:0,background:'rgba(0,0,0,.5)',zIndex:40}}/>
            <div style={{position:'fixed',left:0,top:0,bottom:0,zIndex:50,animation:'slideIn .28s ease'}}><SB/></div>
          </>
        )}

        {/* Main */}
        <div style={{flex:1,display:'flex',flexDirection:'column',overflow:'hidden',minWidth:0}}>

          {/* Topbar */}
          <div style={{height:56,background:'rgba(240,237,232,.92)',backdropFilter:'blur(16px)',WebkitBackdropFilter:'blur(16px)',borderBottom:`1px solid ${T.bd}`,display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 16px',flexShrink:0}}>
            <div style={{display:'flex',alignItems:'center',gap:11}}>
              {isMob && <button onClick={()=>setMobSb(true)} style={{width:36,height:36,borderRadius:9,background:'rgba(42,26,20,.06)',border:'none',cursor:'pointer',fontSize:19,display:'flex',alignItems:'center',justifyContent:'center'}}>☰</button>}
              <span style={{fontFamily:"'Fraunces',serif",fontWeight:isMob?700:300,fontSize:isMob?15:20,color:T.br}}>
                {isMob ? <>sellr<span style={{color:T.tr,fontWeight:300}}>.ai</span></> : NAV.find(n=>n.id===view)?.label}
              </span>
            </div>
            <div style={{display:'flex',alignItems:'center',gap:9}}>
              {!isMob && <span style={{fontSize:13,color:T.br3}}>{uName}</span>}
              {u.image
                ? <img src={u.image} alt="" width={33} height={33} style={{borderRadius:'50%',objectFit:'cover',flexShrink:0}}/>
                : <div style={{width:33,height:33,borderRadius:'50%',background:T.br,color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700,fontSize:13,flexShrink:0}}>{initials}</div>}
              <button onClick={()=>signOut({callbackUrl:'/login'})}
                style={{padding:'5px 11px',borderRadius:999,background:'rgba(42,26,20,.06)',border:`1px solid ${T.bd}`,fontSize:12,color:T.br3,cursor:'pointer',fontFamily:'inherit',transition:'all .16s'}}
                onMouseEnter={e=>{e.currentTarget.style.color=T.br;e.currentTarget.style.borderColor='rgba(42,26,20,.25)'}}
                onMouseLeave={e=>{e.currentTarget.style.color=T.br3;e.currentTarget.style.borderColor=T.bd}}>
                Logout
              </button>
            </div>
          </div>

          {/* Content */}
          <div style={{flex:1,overflow:view==='chat'?'hidden':'auto',padding:isMob?11:16}}>
            {views[view]}
          </div>

          {/* Mobile bottom nav */}
          {isMob && (
            <div style={{height:58,background:'rgba(240,237,232,.95)',backdropFilter:'blur(16px)',borderTop:`1px solid ${T.bd}`,display:'flex',alignItems:'center',justifyContent:'space-around',paddingBottom:'env(safe-area-inset-bottom,0)',flexShrink:0}}>
              {NAV.map(n=>(
                <button key={n.id} onClick={()=>nav(n.id)} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:2,padding:'4px 7px',borderRadius:9,background:'none',border:'none',cursor:'pointer',fontFamily:'inherit',fontSize:9,color:view===n.id?T.tr:T.br3,fontWeight:view===n.id?700:400,minWidth:48}}>
                  <span style={{fontSize:18}}>{n.ic}</span>
                  {n.label.split(' ')[0]}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  )
}
