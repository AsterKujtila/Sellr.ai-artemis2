'use client'
import { useState, useRef, useEffect, useCallback } from 'react'

const T = { cr2:'#e8e4de',cr3:'#ddd8d0',br:'#2a1a14',br2:'#5a3a2e',br3:'#8a7a74',tr:'#c4724a',trs:'#f5e8e0',bd:'#e0d8d0' }

const CHIPS = [
  "Why isn't my store converting?","Write my offer headline",
  "How to price my community?","Roast my sales page",
  "Create a 7-day launch plan","What upsells should I add?",
  "Improve my product description","How to grow on Whop?",
]

type Msg = { role: 'user'|'assistant'; content: string }

function Dots() {
  return (
    <div style={{alignSelf:'flex-start',padding:'10px 16px',background:T.br,borderRadius:14,display:'inline-flex',gap:5,alignItems:'center',animation:'msgIn .3s ease'}}>
      {[0,1,2].map(i=><div key={i} style={{width:6,height:6,borderRadius:'50%',background:T.tr,animation:`dot .72s ease-in-out infinite ${i*.15}s`}}/>)}
    </div>
  )
}

export default function Chat({ name }: { name: string }) {
  const [msgs, setMsgs]         = useState<Msg[]>([{ role:'assistant', content:`Hey ${name.split(' ')[0]} 👋 I'm SELLR — your AI sales coach built exclusively for Whop.\n\nAsk me anything about your store, pricing, offers, or copy. I give specific, real advice — no fluff.\n\nWhat's the biggest problem with your Whop store right now?` }])
  const [input, setInput]       = useState('')
  const [loading, setLoading]   = useState(false)
  const [err, setErr]           = useState<string|null>(null)
  const [chips, setChips]       = useState(true)
  const [micOn, setMicOn]       = useState(false)
  const [hasVoice, setHasVoice] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)
  const taRef     = useRef<HTMLTextAreaElement>(null)
  const recRef    = useRef<any>(null)
  const ttsRef    = useRef<SpeechSynthesisUtterance|null>(null)

  useEffect(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (!SR) return
    setHasVoice(true)
    const r = new SR(); r.continuous=false; r.lang='en-US'
    r.onresult = (e: any) => { const t=e.results[0]?.[0]?.transcript||''; if(t) send(t) }
    r.onend = () => setMicOn(false)
    r.onerror = () => setMicOn(false)
    recRef.current = r
  }, [])

  useEffect(() => { bottomRef.current?.scrollIntoView({behavior:'smooth'}) }, [msgs, loading])

  const send = useCallback(async (override?: string) => {
    const text = (override ?? input).trim()
    if (!text || loading) return
    setInput(''); setErr(null); setChips(false)
    if (taRef.current) taRef.current.style.height = 'auto'
    const next: Msg[] = [...msgs, { role:'user', content:text }]
    setMsgs(next); setLoading(true)
    try {
      const res = await fetch('/api/chat', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({messages:next}) })
      const d = await res.json()
      if (!res.ok || d.error) throw new Error(d.error||`Error ${res.status}`)
      setMsgs(p => [...p, { role:'assistant', content:d.text }])
    } catch(e: any) { setErr(e.message) }
    finally { setLoading(false) }
  }, [input, msgs, loading])

  const toggleMic = () => {
    if (!recRef.current) return
    if (micOn) { recRef.current.stop(); setMicOn(false) }
    else { try { recRef.current.start(); setMicOn(true) } catch { setMicOn(false) } }
  }

  const speak = (text: string, btn: HTMLButtonElement) => {
    if (!window.speechSynthesis) return
    if (ttsRef.current) { window.speechSynthesis.cancel(); ttsRef.current=null; btn.textContent='🔊'; return }
    const u = new SpeechSynthesisUtterance(text.slice(0,600))
    u.rate = 1.05
    const v = window.speechSynthesis.getVoices().find(v=>v.lang==='en-US')
    if (v) u.voice = v
    u.onend = u.onerror = () => { ttsRef.current=null; btn.textContent='🔊' }
    ttsRef.current = u; btn.textContent='⏹'
    window.speechSynthesis.speak(u)
  }

  const copy = (text: string, btn: HTMLButtonElement) => {
    navigator.clipboard?.writeText(text).catch(()=>{})
    btn.textContent='✓'; setTimeout(()=>{ btn.textContent='⎘' },2000)
  }

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',background:'#fff',borderRadius:20,border:`1px solid ${T.bd}`,overflow:'hidden'}}>
      {/* Header */}
      <div style={{padding:'12px 16px',borderBottom:`1px solid ${T.bd}`,display:'flex',alignItems:'center',gap:10,flexShrink:0}}>
        <div style={{width:36,height:36,borderRadius:'50%',background:T.br,color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700,fontSize:14,flexShrink:0}}>S</div>
        <div style={{flex:1}}>
          <div style={{fontWeight:700,fontSize:14,color:T.br}}>SELLR</div>
          <div style={{fontSize:11,color:T.br3}}>AI Sales Coach · Powered by Claude</div>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:5,background:'rgba(74,222,128,.09)',color:'#16a34a',padding:'4px 10px',borderRadius:999,fontSize:11,fontWeight:600,flexShrink:0}}>
          <div style={{width:5,height:5,borderRadius:'50%',background:'#16a34a',animation:'ping 2s infinite'}}/>Live
        </div>
        <button onClick={()=>{setMsgs([{role:'assistant',content:'Fresh start 🔥 What do you want to work on?'}]);setChips(true);setErr(null)}}
          style={{padding:'5px 10px',borderRadius:8,background:'rgba(42,26,20,.05)',border:`1px solid ${T.bd}`,fontSize:11,color:T.br3,cursor:'pointer'}}>
          Clear
        </button>
      </div>

      {/* Chips */}
      {chips && (
        <div style={{display:'flex',gap:6,overflowX:'auto',padding:'8px 14px',borderBottom:`1px solid ${T.bd}`,flexShrink:0}}>
          {CHIPS.map((c,i) => (
            <button key={i} onClick={()=>{setChips(false);send(c)}}
              style={{flexShrink:0,background:T.cr2,border:`1px solid ${T.bd}`,borderRadius:999,padding:'6px 11px',fontSize:12,color:T.br2,cursor:'pointer',whiteSpace:'nowrap',fontFamily:'inherit',transition:'all .15s'}}
              onMouseEnter={e=>{const b=e.currentTarget;b.style.background=T.trs;b.style.borderColor=T.tr;b.style.color=T.tr}}
              onMouseLeave={e=>{const b=e.currentTarget;b.style.background=T.cr2;b.style.borderColor=T.bd;b.style.color=T.br2}}>
              {c}
            </button>
          ))}
        </div>
      )}

      {/* Messages */}
      <div style={{flex:1,overflowY:'auto',padding:16,display:'flex',flexDirection:'column',gap:10}}>
        {msgs.map((m,i) => (
          <div key={i} style={{display:'flex',flexDirection:'column',alignItems:m.role==='user'?'flex-end':'flex-start',gap:4,animation:'msgIn .3s ease'}}>
            <div style={{
              maxWidth:'88%',padding:'11px 15px',
              borderRadius:m.role==='user'?'18px 18px 3px 18px':'18px 18px 18px 3px',
              background:m.role==='user'?T.br:T.cr2,
              color:m.role==='user'?'#fff':T.br,
              fontSize:14,fontWeight:300,lineHeight:1.65,
              border:m.role==='assistant'?`1px solid ${T.bd}`:'none',
              wordBreak:'break-word',whiteSpace:'pre-wrap',
            }}>
              {m.content}
            </div>
            {m.role==='assistant' && i>0 && (
              <div style={{display:'flex',gap:5,marginLeft:4}}>
                <button onClick={e=>copy(m.content,e.currentTarget as HTMLButtonElement)}
                  style={{padding:'3px 9px',borderRadius:6,background:'rgba(42,26,20,.06)',border:`1px solid ${T.bd}`,fontSize:11,color:T.br3,cursor:'pointer',fontFamily:'inherit'}}>⎘</button>
                <button onClick={e=>speak(m.content,e.currentTarget as HTMLButtonElement)}
                  style={{padding:'3px 9px',borderRadius:6,background:'rgba(42,26,20,.06)',border:`1px solid ${T.bd}`,fontSize:11,color:T.br3,cursor:'pointer',fontFamily:'inherit'}}>🔊</button>
              </div>
            )}
          </div>
        ))}
        {loading && <Dots/>}
        {err && <div onClick={()=>setErr(null)} style={{alignSelf:'center',background:'rgba(239,68,68,.08)',border:'1px solid rgba(239,68,68,.2)',borderRadius:12,padding:'9px 14px',fontSize:13,color:'#dc2626',cursor:'pointer',textAlign:'center',maxWidth:'90%'}}>⚠️ {err} (tap to dismiss)</div>}
        <div ref={bottomRef}/>
      </div>

      {/* Input */}
      <div style={{padding:'10px 14px',borderTop:`1px solid ${T.bd}`,background:'#fff',flexShrink:0}}>
        {micOn && <div style={{textAlign:'center',fontSize:12,color:T.tr,fontWeight:500,marginBottom:6}}>🎤 Listening...</div>}
        <div style={{display:'flex',alignItems:'flex-end',gap:7}}>
          <textarea ref={taRef} value={input}
            onChange={e=>{setInput(e.target.value);e.target.style.height='auto';e.target.style.height=Math.min(e.target.scrollHeight,120)+'px'}}
            onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}}}
            placeholder="Ask about your Whop store..." disabled={loading} maxLength={800} rows={1}
            style={{flex:1,background:T.cr2,border:`1.5px solid ${T.bd}`,borderRadius:18,padding:'10px 14px',fontSize:16,color:T.br,resize:'none',outline:'none',lineHeight:1.5,minHeight:42,maxHeight:120,transition:'border-color .2s',boxSizing:'border-box'}}
            onFocus={e=>e.target.style.borderColor=T.tr} onBlur={e=>e.target.style.borderColor=T.bd}/>
          {hasVoice && (
            <button onClick={toggleMic} style={{width:40,height:40,borderRadius:'50%',background:micOn?'rgba(196,114,74,.15)':T.cr2,border:`1.5px solid ${micOn?T.tr:T.bd}`,display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',flexShrink:0,fontSize:16,transition:'all .2s'}}>🎤</button>
          )}
          <button onClick={()=>send()} disabled={loading||!input.trim()}
            style={{width:40,height:40,borderRadius:'50%',background:loading||!input.trim()?T.cr3:T.tr,border:'none',color:'#fff',cursor:loading||!input.trim()?'not-allowed':'pointer',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,fontSize:16,transition:'all .2s'}}>
            ↑
          </button>
        </div>
        <div style={{fontSize:10,color:T.br3,textAlign:'right',marginTop:4,fontFamily:"'JetBrains Mono',monospace"}}>{input.length}/800 · Enter to send</div>
      </div>
    </div>
  )
}
